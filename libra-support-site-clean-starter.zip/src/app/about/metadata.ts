export const metadata = {
  title: "About Us | Libra Support Services",
  description:
    "Learn more about Libra Support Services, our mission, values, and dedication to person-centered home care across West Yorkshire.",
};
