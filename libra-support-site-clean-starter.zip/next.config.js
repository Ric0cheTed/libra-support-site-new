const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
});

/** @type {import('next').NextConfig} */
const nextConfig = withBundleAnalyzer({
  reactStrictMode: true,
  trailingSlash: true,
  output: 'export',
  images: {
    domains: ['libra-support.vercel.app'],
  },
});

module.exports = nextConfig;
